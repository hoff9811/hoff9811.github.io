# Master Function
ProcessBXSScenarios <- function(df) {
  df %>% 
    rename_with(~ tolower(gsub("..", "_", .x, fixed = TRUE))) %>% 
    rename_with(~ gsub(".", "_", .x, fixed = TRUE)) %>% 
    rename_with(~ gsub("level_", "level", .x, fixed = TRUE)) %>% 
    
    # 3: Dow Jones, HPI, CREPI - Annualize Q Growth then Apply Moving Average
    mutate(across(dow_jones_total_stock_market_index_level:
                    commercial_real_estate_price_index_level , 
                  AnnualizeQGrowth,
                  .names = "{col}_growth")) %>% 
    rename_with(~ gsub("level_growth", "growth", .x, fixed = TRUE)) %>% 
    
    #4. Add the Spread Variables
    mutate(x3_month_to_10_year_treasury_spread = x10_year_treasury_yield - x3_month_treasury_rate,
           bbb_to_10_year_corporate_yield_spread = bbb_corporate_yield - x10_year_treasury_yield) %>% 
    
    filter(date >= '2022 Q2')
}

for (i in c("upside", "base", "50_50_basedownside", "downside")) {
  # Read in from Excel.
  assign(
    paste0("econscenario_", i),
    read.csv(paste0("bxs_scenario_", i, ".csv")) %>% 
    tibble() %>% 
    mutate(date = as.yearqtr(date)) %>% 
    ProcessBXSScenarios()
  )
}

#-----------------------------------------


scenario_upside <- NULL
scenario_downside <- NULL
scenario_base <- NULL
scenario_50_50_basedownside <- NULL

for(i_portfolio in portfolio_colors$portfolio) {
  i_variables <- 
    final_models %>% 
    filter(portfolio == i_portfolio) %>% 
    select(X1, X2, X3) %>% 
    t() %>% 
    c()
  
  i_model <- pull(subset(final_models, portfolio == i_portfolio, model))[[1]]
  
  # Upside 
  i_scenario_upside <- 
    econscenario_upside %>% 
    select(c(date, all_of(i_variables)))
           
  i_scenario_upside <-
    i_scenario_upside %>% 
    mutate(forecast  = predict(i_model, newdata = i_scenario_upside),
           portfolio = i_portfolio) %>% 
    group_by(portfolio) %>% 
    nest(.key = "upside")
  
  scenario_upside <- union_all(scenario_upside, i_scenario_upside)
  
  # Downside
  i_scenario_downside <- 
    econscenario_downside %>% 
    select(c(date, all_of(i_variables)))
  
  i_scenario_downside <-
    i_scenario_downside %>% 
    mutate(forecast  = predict(i_model, newdata = i_scenario_downside),
           portfolio = i_portfolio) %>% 
    group_by(portfolio) %>% 
    nest(.key = "downside")
  
  scenario_downside <- union_all(scenario_downside, i_scenario_downside)
  
  # Base
  i_scenario_base <- 
    econscenario_base %>% 
    select(c(date, all_of(i_variables)))
  
  i_scenario_base <-
    i_scenario_base %>% 
    mutate(forecast  = predict(i_model, newdata = i_scenario_base),
           portfolio = i_portfolio) %>% 
    group_by(portfolio) %>% 
    nest(.key = "base")
  
  scenario_base <- union_all(scenario_base, i_scenario_base)
  
  # 50_50_basedownside
  i_scenario_50_50_basedownside <- 
    econscenario_50_50_basedownside %>% 
    select(c(date, all_of(i_variables)))
  
  i_scenario_50_50_basedownside <-
    i_scenario_50_50_basedownside %>% 
    mutate(forecast  = predict(i_model, newdata = i_scenario_50_50_basedownside),
           portfolio = i_portfolio) %>% 
    group_by(portfolio) %>% 
    nest(.key = "x50_50_basedownside")
  
  scenario_50_50_basedownside <- union_all(scenario_50_50_basedownside, 
                                           i_scenario_50_50_basedownside)
}

final_models_scenarios <-
  final_models %>% 
  select(portfolio, X1, X2, X3,data, model_fitted) %>% 
  left_join(scenario_upside, by = "portfolio") %>% 
  left_join(scenario_downside, by = "portfolio") %>% 
  left_join(scenario_base, by = "portfolio") %>% 
  left_join(scenario_50_50_basedownside, by = "portfolio") 


#-------------------------
PlotFinalModel <- function(i_portfolio, i_sublabel)  {
  i_color = pull(subset(portfolio_colors, portfolio == i_portfolio, color))
  i_fill  = pull(subset(portfolio_colors, portfolio == i_portfolio, fill))
  
  final_models_plotdata <-
    final_models_scenarios %>% 
    filter(portfolio == i_portfolio) %>% 
    select(model_fitted, upside, downside, base, x50_50_basedownside) %>%
    mutate(all_data = map2(model_fitted, upside, union_all)) %>%
    mutate(all_data = map2(all_data, downside, ~left_join(.x, .y, by = "date", suffix = c("", "_downside")))) %>%
    mutate(all_data = map2(all_data, base, ~left_join(.x, .y, by = "date", suffix = c("", "_base")))) %>%
    mutate(all_data = map2(all_data, x50_50_basedownside, ~left_join(.x, .y, by = "date", suffix = c("", "_5050")))) %>%
    unnest(all_data) %>%
    select(date, depvar, .fitted, forecast, forecast_downside, forecast_base, forecast_5050) %>% 
    rename(upside = forecast, downside = forecast_downside, base = forecast_base, updown_5050 = forecast_5050) %>% 
    pivot_longer(cols = c(".fitted", "upside", "downside", "base", "updown_5050"))
  
  
  p1 <- 
    final_models_plotdata %>%
    ggplot(aes(y = value, x = as.Date(date), color = name)) +
    geom_line(lwd = 0.7, linetype = 5)+
    scale_y_continuous(
      name = "Loss Rate (%)",
      labels = scales::percent
    ) +
    xlab("Quarter") +
    scale_color_manual(values = c("black", "light green", "red", "orange", "green")) +
    geom_area(aes(y = depvar), position = "identity", color = i_color, fill = i_fill, alpha = 0.5)+
    ggtitle(paste0(i_portfolio, " Final Model"), i_sublabel) +
    theme_bw()
  
  print(p1)
  myppt <-
    myppt %>%
    add_slide(layout="11_Custom Layout") %>%
    ph_with(type = "title",
            value = paste0("Model Selection: ", i_portfolio),
            ph_location_type(type = "title")) %>%
    ph_with(dml(ggobj = p1),
            location = ph_location(width = 8.9, height = 2.8,
                                   left = .54, top = 2.46))
  
  
  #write.csv(final_models_plotdata, paste0("forecast_",i_portfolio, ".csv"))
  
  indvar_model <-
    final_models_scenarios %>% 
    filter(portfolio == i_portfolio) %>% 
    select(data, upside, downside, base, x50_50_basedownside) %>%
    mutate(all_data = map2(x50_50_basedownside, upside, ~left_join(.x, .y, by = "date", suffix = c("_5050", "_upside")))) %>%
    mutate(all_data2 = map2(base, downside, ~left_join(.x, .y, by = "date", suffix = c("_base", "_downside")))) %>%
    mutate(all_data = map2(all_data, all_data2, ~left_join(.x, .y, by = "date"))) %>%
    mutate(all_data = map2(all_data, data, union_all)) %>%

    unnest(all_data) %>%
    select(-data, -upside, -downside, -depvar, -base, -x50_50_basedownside, -all_data2) %>%
    select(-starts_with("forecast")) %>% 
    pivot_longer(cols = -date) %>%
    mutate(Scenario = ifelse(endsWith(name, "upside"),
                             "upside",
                             ifelse(endsWith(name, "downside"), "downside", 
                                    ifelse(endsWith(name, "base"), "base",
                                           ifelse(endsWith(name, "5050"), "5050", "historical")
          )))) %>%
    mutate(Variable = gsub("_upside","", name)) %>%
    mutate(Variable = gsub("_downside","", Variable)) %>% 
    mutate(Variable = gsub("_base","", Variable)) %>% 
    mutate(Variable = gsub("_5050","", Variable)) 

  
  p2 <-
    indvar_model %>%
    ggplot(aes(y = value, x = as.Date(date), color = Scenario)) +
    geom_line(lwd = 0.7) +
    xlab("Quarter") +
    scale_color_manual(values = c("orange", "light green", "red", "black", "light green")) +
    theme_bw() +
    ggtitle(paste0(i_portfolio, " Final Model"), "Cadence Bank Scenarios") +
    facet_wrap(vars(Variable), scales = "free_y", ncol = 2)
  
  myppt <-
    myppt %>%
    add_slide(layout="11_Custom Layout") %>%
    ph_with(type = "title",
            value = paste0("Final Models: ", i_portfolio),
            ph_location_type(type = "title")) %>%
    ph_with(dml(ggobj = p2),
            location = ph_location(width = 9, height = 3.9,
                                   left = .54, top = 1.36))
  
}


myppt <- read_pptx("C:\\Users\\e1075351\\Desktop\\BXS 2022\\FIS-CadenceBank CECL Recal Project Weekly Update RSHELL.pptx")

PlotFinalModel("CREIP", "Cadence Bank Scenarios") 
PlotFinalModel("Construction", "Cadence Bank Scenarios") 
PlotFinalModel("Mortgage", "Cadence Bank Scenarios") 
PlotFinalModel("OtherConsumer", "Cadence Bank Scenarios") 
PlotFinalModel("CnIFarmOther", "Cadence Bank Scenarios") 

print(myppt, target = "C:\\Users\\e1075351\\Desktop\\BXS 2022\\FIS-CadenceBank CECL Recal Project Weekly Update ROUTPUT.pptx")
