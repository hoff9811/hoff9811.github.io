#---------------------------
# BXS CECL - Week 1 Presentation
#---------------------------

source("02_LineItem_PortfolioDataImport.R")

# Define the Bank Data series
legacy_BXS <- 
  cadencecharters_portfolio %>% 
  filter(PeerId < -3) 

legacy_cadence <- 
  cadencecharters_portfolio %>% 
  filter(PeerId == -3| PeerId == -2) 

legacy_BXS$Name <- factor(legacy_BXS$Name, 
                          levels = c("Icon Bank of Texas, National Association",
                                     "Grand Bank of Texas",
                                     "Merchants Bank",
                                     "Summit Bank, National Association",
                                     "Texas Star Bank",
                                     "Texas First State Bank",
                                     "National United",
                                     "FNB Bank",
                                     "BancorpSouth Bank"))

legacy_cadence$Name <- factor(legacy_cadence$Name,
                              levels =c("State Bank and Trust Company",
                                        "Cadence Bank, N.A."))

# Aggregate all NCOs for both BXS and Cadence
legacy_BXS_NCO <-
  legacy_BXS %>% 
  group_by(date) %>% 
  summarise_at(vars(CnIFarmOther_CO:OtherConsumer_NLL), hablar::sum_) %>% 
  CalculatePortfolioNCOs() 

legacy_cadence_NCO <-
  legacy_cadence %>% 
  group_by(date) %>% 
  summarise_at(vars(CnIFarmOther_CO:OtherConsumer_NLL), hablar::sum_) %>% 
  CalculatePortfolioNCOs() 

#------------------------------------------------
# Total Assets Chart 
legacy_BXS %>% 
  filter(is.na(TotalAssets) == FALSE) %>%
  ggplot(aes(x = date, 
             y = TotalAssets, 
             fill = Name)) +
  geom_area(color = "grey") +  
  scale_y_continuous(
    name = "Total Assets ($)",
    labels = scales::dollar,
    limits = c(0, NA)
  ) +
  scale_fill_manual(values = cc) +
  ggtitle("Legacy BancorpSouth Bank: Total Assets") +
  theme_bw()

legacy_BXS %>% 
  filter(Name != "BancorpSouth Bank") %>% 
  ggplot(aes(x = date, y = TotalAssets)) +
  geom_area(fill = "#B9D989", color = "#4BCD3E") +  
  scale_y_continuous(
    name = "Total Assets ($)",
    labels = scales::dollar,
    limits = c(0, NA)
  ) +
  ggtitle("Legacy BancorpSouth Bank Acquisitions: Total Assets") +
  theme_bw() + 
  facet_wrap(vars(Name), ncol = 3)

legacy_Cadence %>% 
  filter(is.na(TotalAssets) == FALSE) %>% 
  ggplot(aes(x = date, y = TotalAssets, fill = Name)) +
  geom_area(color = "#015B7E") +  
  scale_y_continuous(
    name = "Total Assets ($)",
    labels = scales::dollar,
    limits = c(0, NA)
  ) +
  scale_fill_manual(values = c("#B3E9FE","#015B7E")) +
  ggtitle("Legacy Cadence Bank: Total Assets") +
  theme_bw()


#-------------------------------------------------
# Net Charge-off series charts for all Acquisitions
for(i_portfolio in colnames(portfolio_mapping)) {
  # Legacy BXS
  print(
    legacy_BXS_NCO %>% 
      ggplot(aes(x = date, 
                 y = !! sym(paste0(i_portfolio,"_NCO")))) +
      geom_area(fill = "#B9D989", color = "#4BCD3E") +  
      scale_y_continuous(
        name = "Net Charge-off Rate (%)",
        labels = scales::percent
      ) +
      ggtitle(paste0("Legacy BancorpSouth Bank + Acquisitions: ", i_portfolio, " Portfolio")) +
      theme_bw()
  )
  
  # All BXS Acquisitions
  print(
    legacy_BXS %>% 
      ggplot(aes(x = date, 
                 y = !! sym(paste0(i_portfolio,"_NCO")))) +
      geom_area(fill = "#B9D989", color = "#4BCD3E") +  
      scale_y_continuous(
        name = "Net Charge-off Rate (%)",
        labels = scales::percent
      ) +
      ggtitle(paste0("Legacy BancorpSouth Bank Acquisitions: ", i_portfolio, " Portfolio")) +
      theme_bw() + 
      facet_wrap(vars(Name), ncol = 3)
  )
  
  # Legacy Cadence
  print(
    legacy_cadence_NCO %>% 
      ggplot(aes(x = date, 
                 y = !! sym(paste0(i_portfolio,"_NCO")))) +
      geom_area(fill = "#B3E9FE", color = "#015B7E") + 
      scale_y_continuous(
        name = "Net Charge-off Rate (%)",
        labels = scales::percent
      ) +
      ggtitle(paste0("Legacy Cadence Bank + Acquisitions: ", i_portfolio, " Portfolio")) +
      theme_bw()
  )
  
  print(
    legacy_cadence %>% 
      ggplot(aes(x = date, 
                 y = !! sym(paste0(i_portfolio,"_NCO")))) +
      geom_area(fill = "#B3E9FE", color = "#015B7E") + 
      scale_y_continuous(
        name = "NCO (%)",
        labels = scales::percent
      ) +
      ggtitle(paste0("Legacy Cadence Bank Acquisitions: ", i_portfolio, " Portfolio")) +
      theme_bw() + 
      facet_wrap(vars(Name), ncol = 2)
  )
}

#-------------------------------
# Net Loans and Leases over Time
#-------------------------------
legacy_BXS %>% 
  select(date,
         CnIFarmOther_NLL, 
         CREIP_NLL, 
         Construction_NLL, 
         Mortgage_NLL, 
         OtherConsumer_NLL) %>% 
  group_by(date) %>% 
  summarize_all(~sum(.x, na.rm = TRUE)) %>% 
  pivot_longer(cols = c("CnIFarmOther_NLL":"OtherConsumer_NLL"),
               names_to = "portfolio") %>% 
  mutate(Portfolio = factor(portfolio, 
                            levels = c("OtherConsumer_NLL",
                                       "Mortgage_NLL",
                                       "Construction_NLL",
                                       "CREIP_NLL",
                                       "CnIFarmOther_NLL"))
  ) %>% 
  ggplot(aes(x = date, 
             y = value, 
             fill = Portfolio)) +
  geom_area(color = "grey") +  
  scale_y_continuous(
    name = "Net Loans & Leases ($)",
    labels = scales::dollar,
    limits = c(0, NA)
  ) +
  scale_fill_manual(values = tail(cc,5)) +
  ggtitle("Legacy BancorpSouth Bank: Net Loans & Leases") +
  theme_bw()


legacy_cadence %>% 
  select(date,
         CnIFarmOther_NLL, 
         CREIP_NLL, 
         Construction_NLL, 
         Mortgage_NLL, 
         OtherConsumer_NLL) %>% 
  group_by(date) %>% 
  summarize_all(~sum(.x, na.rm = TRUE)) %>% 
  pivot_longer(cols = c("CnIFarmOther_NLL":"OtherConsumer_NLL"),
               names_to = "portfolio") %>% 
  mutate(Portfolio = factor(portfolio, 
                            levels = c("OtherConsumer_NLL",
                                       "Mortgage_NLL",
                                       "Construction_NLL",
                                       "CREIP_NLL",
                                       "CnIFarmOther_NLL"))
  ) %>% 
  ggplot(aes(x = date, 
             y = value, 
             fill = Portfolio)) +
  geom_area(color = "grey") +  
  scale_y_continuous(
    name = "Net Loans & Leases ($)",
    labels = scales::dollar,
    limits = c(0, NA)
  ) +
  scale_fill_manual(values = tail(cc2,5)) +
  ggtitle("Legacy Cadence Bank: Net Loans & Leases") +
  theme_bw()