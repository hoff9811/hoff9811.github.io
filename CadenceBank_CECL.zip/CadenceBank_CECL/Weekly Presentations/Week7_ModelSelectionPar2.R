# CREIP Candidate Models
# Best 3, 4, 5 factor model
factor3_CREIP <- 
  multifactor_CREIP %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  filter(is.na(X5), is.na(X4), adj.r.squared > 0.5) %>% 
  slice_head(n = 10) 

hasCREPI_CREIP <- 
  multifactor_CREIP %>% 
  #select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(var_flag =  ifelse(grepl("commercial_real_estate", paste(X1, X2, X3, X4, X5)), 1, 0)) %>% 
  filter(adj.r.squared > .5, var_flag == 1) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  slice_head(n = 10)


# C&I Candidate Models
# Best 3, 4, 5 factor model
factor3_CnIFarmOther <- 
  multifactor_CnIFarmOther %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  filter(is.na(X5), is.na(X4), adj.r.squared > 0.5) %>% 
  slice_head(n = 10)

factor5_CnIFarmOther <- 
  multifactor_CnIFarmOther %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  slice_head(n = 10)


# Mortgage Candidate Models
# Best 3, 4, 5 factor model
factor3_Mortgage <- 
  multifactor_Mortgage %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  filter(is.na(X5), is.na(X4), adj.r.squared > 0.5) %>% 
  slice_head(n = 10)

# Construction Candidate Models
# Best 3, 4, 5 factor model
factor3_Construction <- 
  multifactor_Construction %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  filter(is.na(X5), is.na(X4), adj.r.squared > 0.5) %>% 
  slice_head(n = 10)

hasCREPI_Construction <- 
  multifactor_Construction %>% 
  #select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(var_flag =  ifelse(grepl("commercial_real_estate", paste(X1, X2, X3, X4, X5)), 1, 0)) %>% 
  filter(adj.r.squared > .5, var_flag == 1) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  slice_head(n = 10)


myppt <- read_pptx("C:\\Users\\e1075351\\Desktop\\BXS 2022\\FIS-CadenceBank CECL Recal Project Weekly Update RSHELL.pptx")


PlotCandidateModel <- function(i_portfolio, i_modelId, i_sublabel)  {
  i_color = pull(subset(portfolio_colors, portfolio == i_portfolio, color))
  i_fill  = pull(subset(portfolio_colors, portfolio == i_portfolio, fill))

  rank1_model <-
    get(paste0("multifactor_", i_portfolio)) %>%
    filter(modelId == i_modelId) %>% 
    select(model_fitted, forecast_baseline, forecast_SA) %>%
    mutate(all_data = map2(model_fitted, forecast_baseline, union_all)) %>%
    mutate(all_data = map2(all_data, forecast_SA, ~left_join(.x, .y, by = "date", suffix = c("", "_SA")))) %>%
    unnest(all_data) %>%
    rename(baseline = scenario, SA = scenario_SA) %>% 
    mutate(baseline = ifelse(date == "2021 Q4", .fitted, baseline),
           SA = ifelse(date == "2021 Q4", .fitted, SA)) %>%
    pivot_longer(cols = c(".fitted", "baseline", "SA"))
  
  
  p1 <- 
  rank1_model %>%
    ggplot(aes(y = value, x = as.Date(date), color = name)) +
    geom_line(lwd = 0.7, linetype = 5)+
    scale_y_continuous(
      name = "Loss Rate (%)",
      labels = scales::percent
    ) +
    xlab("Quarter") +
    scale_color_manual(values = c("black", "green", "red")) +
    geom_area(aes(y = depvar), position = "identity", color = i_color, fill = i_fill, alpha = 0.5)+
    ggtitle(paste0(i_portfolio, " Candidate Model"), i_sublabel) +
    theme_bw()

  print(p1)
  
  myppt <-
    myppt %>%
    add_slide(layout="11_Custom Layout") %>%
    ph_with(type = "title",
            value = paste0("Model Selection: ", i_portfolio),
            ph_location_type(type = "title")) %>%
    ph_with(dml(ggobj = p1),
            location = ph_location(width = 8.9, height = 2.8,
                                   left = .54, top = 2.46))
 
  
  model_coefs <-
    get(paste0("multifactor_", i_portfolio)) %>%
    filter(modelId == i_modelId) %>%
    select(model_coefs) %>%
    unnest(model_coefs)

  write.csv(model_coefs, paste0("coefs_",i_portfolio, i_modelId, ".csv"))
}

PlotCandidateModel("CREIP", 505, "Top Performing 3-factor Model")
PlotCandidateModel("CREIP", 355, "Top Performing Model w/ CRE Price Index")

PlotCandidateModel("CnIFarmOther", 2873, "Top Performing Model w/o Two Interest Rate Variables")
PlotCandidateModel("CnIFarmOther", 169, "Top Performing Three Factor Model")

PlotCandidateModel("Mortgage", 517 , "Top Performing Three Factor Model")
PlotCandidateModel("Mortgage", 535 , "Top Performing Three Factor Model - Alternate Candidate")

PlotCandidateModel("Construction", 556 , "Top Performing Three Factor Model")
PlotCandidateModel("Construction", 430 , "Top Performing Three Factor Model - Alternate Candidate")
PlotCandidateModel("Construction", 558 , "Top Performing Three Factor Model - Alternate Candidate")


# Write to the new Presentation
# print(myppt, target = "C:\\Users\\e1075351\\Desktop\\BXS 2022\\FIS-CadenceBank CECL Recal Project Weekly Update ROUTPUT.pptx")

#--------------------------------------------------------
##
# Other Consumer

source("02_LineItem_PortfolioDataImport.R")
con_color = pull(subset(portfolio_colors, portfolio == "OtherConsumer", color))
con_fill  = pull(subset(portfolio_colors, portfolio == "OtherConsumer", fill))

# Calculate Peer Group average
newpeeravg <- 
  newpeer_portfolio %>% 
  group_by(date) %>% 
  summarize(across(ends_with("NCO"), hablar::mean_)) %>% 
  mutate(PeerId = 20, Name = "New Peer Group Average")

# For OtherConsumer **only** we are removing seven peers from the peer group
#  East West Bank, 
# Western Alliance Bank
# BankUnited
# Texas Capital Bank
# Pinnacle Bank
# Prosperity Bank
newpeeravg_consumer <-
  newpeer_portfolio %>% 
  filter(!PeerId %in% c(4, 6, 10, 12, 13, 15, 16)) %>% 
  group_by(date) %>% 
  summarize(across(OtherConsumer_NCO, hablar::mean_)) 

newpeer_portfolio %>% 
  group_by(PeerId, Name) %>% 
  summarize(OtherConsumer = hablar::mean_(OtherConsumer_NLL)) %>% 
  arrange(desc(OtherConsumer)) #%>% 
  # write.csv("OtherConsumerAvgNLL.csv")

newpeer_portfolio %>% 
  filter(PeerId > 9) %>% 
  ggplot(aes(x = as.Date(date), y = OtherConsumer_NLL)) +
  geom_area(color = con_color, fill = con_fill) +
  theme_bw() +
  xlab("Quarter") +
  scale_y_continuous(name = "Other Consumer NLL ($)",
                     labels = scales::dollar) +
  facet_wrap(vars(Name))

newpeer_portfolio %>% 
  filter(PeerId > 9) %>% 
  ggplot(aes(x = as.Date(date), y = OtherConsumer_NCO)) +
  geom_area(color = con_color, fill = con_fill) +
  theme_bw() +
  xlab("Quarter") +
  scale_y_continuous(name = "Other Consumer Loss Rate (%)",
                     labels = scales::percent) +
  facet_wrap(vars(Name), scales = "free_y")

## 
# Selection

factor3_OtherConsumer <- 
  multifactor_OtherConsumer %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  filter(is.na(X5), is.na(X4), adj.r.squared > 0.5) %>% 
  slice_head(n = 10) %>% 
  write.csv("OtherConsumer_3factor.csv")

factor5_OtherConsumer <- 
  multifactor_OtherConsumer %>% 
  select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  slice_head(n = 10) %>% 
  write.csv("OtherConsumer_5factor.csv")


hasUR_OtherConsumer <- 
  multifactor_OtherConsumer %>% 
  #select(modelId, X1, X2, X3, X4, X5, adj.r.squared) %>% 
  mutate(var_flag =  ifelse(grepl("unemployment", paste(X1, X2, X3, X4, X5)), 1, 0)) %>% 
  filter(adj.r.squared > .5, var_flag == 1) %>% 
  mutate(across(X1:X5, ~gsub("_", " ", .x))) %>% 
  slice_head(n = 10)

print(
  multifactor_OtherConsumer %>% 
    ggplot(aes(x = adj.r.squared)) +
    geom_histogram(color = con_color, fill = con_fill) +
    ggtitle(paste0("Candidate Models by Adj. R-squared: ", "OtherConsumer"),
            paste0("(n = ", nrow(multifactor_OtherConsumer), ")")) +
    theme_bw()
)

PlotCandidateModel("OtherConsumer", 4984 , "Top Performing Model by Adj. R-squared")
PlotCandidateModel("OtherConsumer", 524 , "Top Performing Three Factor Model")
