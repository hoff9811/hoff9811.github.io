

myppt <- read_pptx("C:\\Users\\e1075351\\Desktop\\BXS 2022\\FIS-CadenceBank CECL Recal Project Weekly Update RSHELL.pptx")


for(i_portfolio in colnames(portfolio_mapping)){
  i_color = pull(subset(portfolio_colors, portfolio == i_portfolio, color))
  i_fill  = pull(subset(portfolio_colors, portfolio == i_portfolio, fill))
  i_count = nrow(get(paste0("multifactor_", i_portfolio)))

  print(
    get(paste0("multifactor_", i_portfolio)) %>%
      ggplot(aes(x = adj.r.squared)) +
      geom_histogram(color = i_color, fill = i_fill) +
      ggtitle(paste0("Candidate Models by Adj. R-squared: ", i_portfolio),
              paste0("(n = ", i_count, ")")) +
      theme_bw()
  )


  rank1_model <-
    get(paste0("multifactor_", i_portfolio)) %>%
    slice_head(n = 1) %>%
    select(model_fitted, forecast_baseline, forecast_SA) %>%
    mutate(all_data = map2(model_fitted, forecast_baseline, union_all)) %>%
    mutate(all_data = map2(all_data, forecast_SA, ~left_join(.x, .y, by = "date", suffix = c("", "_SA")))) %>%
    unnest(all_data) %>%
    rename(baseline = scenario, SA = scenario_SA) %>% 
    mutate(baseline = ifelse(date == "2021 Q4", .fitted, baseline),
           SA = ifelse(date == "2021 Q4", .fitted, SA)) %>%
    pivot_longer(cols = c(".fitted", "baseline", "SA"))

  p1 <- (
  rank1_model %>%
    ggplot(aes(y = value, x = as.Date(date), color = name)) +
    geom_line(lwd = 0.7, linetype = 5)+
    scale_y_continuous(
      name = "Loss Rate (%)",
      labels = scales::percent
    ) +
    xlab("Quarter") +
    scale_color_manual(values = c("black", "green", "red")) +
    geom_area(aes(y = depvar), position = "identity", color = i_color, fill = i_fill, alpha = 0.5)+
    ggtitle(paste0(i_portfolio, " Candidate Model"), "Rank #1 by Adj. R-squared") +
    theme_bw()
  )

  myppt <-
    myppt %>%
    add_slide(layout="11_Custom Layout") %>%
    ph_with(type = "title",
            value = paste0("Model Selection: ", i_portfolio),
            ph_location_type(type = "title")) %>%
    ph_with(dml(ggobj = p1),
            location = ph_location(width = 8.9, height = 2.8,
                                   left = .54, top = 2.46))

  indvar_model <-
    get(paste0("multifactor_", i_portfolio)) %>%
    slice_head(n = 1) %>%
    select(data, indvar_SA, indvar_baseline) %>%
    mutate(all_data = map2(indvar_baseline, indvar_SA, ~left_join(.x, .y, by = "date", suffix = c("_baseline", "_SA")))) %>%
    mutate(all_data = map2(all_data, data, union_all)) %>%
    unnest(all_data) %>%
    select(-data, -indvar_SA, -indvar_baseline, -depvar) %>%
    pivot_longer(cols = -date) %>%
    mutate(Scenario = ifelse(endsWith(name, "baseline"),
                             "baseline",
                             ifelse(endsWith(name, "SA"), "SA", "historical"))) %>%
    mutate(Variable = gsub("_baseline","", name)) %>%
    mutate(Variable = gsub("_SA","", Variable))

  p2 <-
    indvar_model %>%
    ggplot(aes(y = value, x = as.Date(date), color = Scenario)) +
    geom_line(lwd = 0.7) +
    xlab("Quarter") +
    scale_color_manual(values = c("green", "black", "red")) +
    theme_bw() +
    ggtitle(paste0(i_portfolio, " Candidate Variables"), "Rank #1 by Adj. R-squared") +
    facet_wrap(vars(Variable), scales = "free_y", ncol = 2)

  myppt <-
    myppt %>%
    add_slide(layout="11_Custom Layout") %>%
    ph_with(type = "title",
            value = paste0("Model Selection: ", i_portfolio),
            ph_location_type(type = "title")) %>%
    ph_with(dml(ggobj = p2),
            location = ph_location(width = 9, height = 3.9,
                                   left = .54, top = 1.36))

    model_coefs <-
      get(paste0("multifactor_", i_portfolio, "_filter")) %>%
      slice_head(n = 1) %>%
      select(model_coefs) %>%
      unnest(model_coefs)

    model_weight <-
      get(paste0("multifactor_", i_portfolio, "_filter")) %>%
      slice_head(n = 1) %>%
      mutate(mean = map(data, ~summarize_all(.x, hablar::mean_))) %>%
      mutate(sd = map(data, ~summarize_all(.x, hablar::sd_))) %>%
      select(mean, sd) %>%
      unnest(mean, sd)

    write.csv(model_coefs, paste0("coefs_",i_portfolio, ".csv"))
    write.csv(model_weight, paste0("weight_",i_portfolio, ".csv"))


}

test <-
  multifactor_CREIP %>% 
  filter(max_p.value < .1)